//
//  MediaViewController.h
//  VitamioDemo
//
//  Created by pactera on 17/2/23.
//  Copyright © 2017年 pactera. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MediaViewController : UIViewController

@property (nonatomic, strong) NSString *urlString;

@end
