//
//  Vitamio.h
//  Vitamio
//
//  Created by erlz nuo on 7/5/13.
//  Copyright (c) 2013 yixia. All rights reserved.
//


#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import "VDefines.h"
#import "VPlayerManageDef.h"
#import "VMediaPlayer.h"
#import "VMediaPlayerDelegate.h"
#import "VMediaExtracterDef.h"
#import "VMediaExtracter.h"


@interface Vitamio : NSObject

+ (NSString *)version;

@end
