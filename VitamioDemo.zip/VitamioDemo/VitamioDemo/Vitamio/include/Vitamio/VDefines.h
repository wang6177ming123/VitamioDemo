//
//  VDefines.h
//  Vitamio
//
//  Created by erlz nuo on 7/16/13.
//  Copyright (c) 2013 yixia. All rights reserved.
//

#ifndef VITAMIO_VDEFINES_H
#define VITAMIO_VDEFINES_H


#ifdef __cplusplus
#define VITAMIO_EXTERN		extern "C" __attribute__((visibility ("default")))
#else
#define VITAMIO_EXTERN	    extern __attribute__((visibility ("default")))
#endif


#endif
